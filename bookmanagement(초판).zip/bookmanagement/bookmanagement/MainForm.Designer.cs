﻿
namespace bookmanagement
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.RogeBtn = new System.Windows.Forms.Button();
            this.ID = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.IDfind = new System.Windows.Forms.Label();
            this.Join = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BookBtn = new System.Windows.Forms.Button();
            this.adminBtn = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.BookManagPan = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BookRetunPan = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.bookReturnPan = new System.Windows.Forms.ListBox();
            this.BookSerchBtn = new System.Windows.Forms.Button();
            this.BookRetunBtn = new System.Windows.Forms.Button();
            this.BookManagBtn = new System.Windows.Forms.Button();
            this.BookSearchPan = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.ManagementBtn = new System.Windows.Forms.Button();
            this.MemberBtn = new System.Windows.Forms.Button();
            this.BookRequestBtn = new System.Windows.Forms.Button();
            this.BookRequestPan = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.MemberPan = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.BookManagPan.SuspendLayout();
            this.BookRetunPan.SuspendLayout();
            this.BookSearchPan.SuspendLayout();
            this.BookRequestPan.SuspendLayout();
            this.MemberPan.SuspendLayout();
            this.SuspendLayout();
            // 
            // RogeBtn
            // 
            this.RogeBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.RogeBtn.Location = new System.Drawing.Point(939, 101);
            this.RogeBtn.Name = "RogeBtn";
            this.RogeBtn.Size = new System.Drawing.Size(78, 42);
            this.RogeBtn.TabIndex = 0;
            this.RogeBtn.Text = "로그인";
            this.RogeBtn.UseVisualStyleBackColor = true;
            // 
            // ID
            // 
            this.ID.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ID.Location = new System.Drawing.Point(939, 12);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(216, 25);
            this.ID.TabIndex = 1;
            // 
            // Password
            // 
            this.Password.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Password.Location = new System.Drawing.Point(939, 58);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(216, 25);
            this.Password.TabIndex = 1;
            // 
            // IDfind
            // 
            this.IDfind.AutoSize = true;
            this.IDfind.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.IDfind.Location = new System.Drawing.Point(1023, 103);
            this.IDfind.Name = "IDfind";
            this.IDfind.Size = new System.Drawing.Size(134, 13);
            this.IDfind.TabIndex = 2;
            this.IDfind.Text = "아이디/비밀번호 찾기";
            this.IDfind.Click += new System.EventHandler(this.IDfind_Click);
            // 
            // Join
            // 
            this.Join.AutoSize = true;
            this.Join.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Join.Location = new System.Drawing.Point(1023, 122);
            this.Join.Name = "Join";
            this.Join.Size = new System.Drawing.Size(59, 13);
            this.Join.TabIndex = 2;
            this.Join.Text = "회원가입";
            this.Join.Click += new System.EventHandler(this.Join_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(844, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 75);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // BookBtn
            // 
            this.BookBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BookBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BookBtn.FlatAppearance.BorderSize = 0;
            this.BookBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookBtn.Image = ((System.Drawing.Image)(resources.GetObject("BookBtn.Image")));
            this.BookBtn.Location = new System.Drawing.Point(24, 22);
            this.BookBtn.Name = "BookBtn";
            this.BookBtn.Size = new System.Drawing.Size(93, 104);
            this.BookBtn.TabIndex = 4;
            this.BookBtn.UseVisualStyleBackColor = true;
            this.BookBtn.Click += new System.EventHandler(this.BookBtn_Click);
            // 
            // adminBtn
            // 
            this.adminBtn.FlatAppearance.BorderSize = 0;
            this.adminBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminBtn.Image = ((System.Drawing.Image)(resources.GetObject("adminBtn.Image")));
            this.adminBtn.Location = new System.Drawing.Point(117, 22);
            this.adminBtn.Name = "adminBtn";
            this.adminBtn.Size = new System.Drawing.Size(91, 104);
            this.adminBtn.TabIndex = 4;
            this.adminBtn.UseVisualStyleBackColor = true;
            this.adminBtn.Click += new System.EventHandler(this.adminBtn_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Items.AddRange(new object[] {
            "도서관리"});
            this.listBox1.Location = new System.Drawing.Point(7, 51);
            this.listBox1.MultiColumn = true;
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(714, 364);
            this.listBox1.TabIndex = 5;
            // 
            // BookManagPan
            // 
            this.BookManagPan.Controls.Add(this.button7);
            this.BookManagPan.Controls.Add(this.button6);
            this.BookManagPan.Controls.Add(this.button5);
            this.BookManagPan.Controls.Add(this.textBox6);
            this.BookManagPan.Controls.Add(this.textBox5);
            this.BookManagPan.Controls.Add(this.textBox4);
            this.BookManagPan.Controls.Add(this.textBox3);
            this.BookManagPan.Controls.Add(this.textBox2);
            this.BookManagPan.Controls.Add(this.label8);
            this.BookManagPan.Controls.Add(this.label7);
            this.BookManagPan.Controls.Add(this.label6);
            this.BookManagPan.Controls.Add(this.label5);
            this.BookManagPan.Controls.Add(this.textBox1);
            this.BookManagPan.Controls.Add(this.label4);
            this.BookManagPan.Controls.Add(this.label3);
            this.BookManagPan.Controls.Add(this.listBox1);
            this.BookManagPan.Location = new System.Drawing.Point(17, 190);
            this.BookManagPan.Name = "BookManagPan";
            this.BookManagPan.Size = new System.Drawing.Size(1145, 453);
            this.BookManagPan.TabIndex = 7;
            this.BookManagPan.Visible = false;
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Default;
            this.button7.Location = new System.Drawing.Point(948, 373);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(106, 42);
            this.button7.TabIndex = 8;
            this.button7.Text = "신청목록";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Default;
            this.button6.Location = new System.Drawing.Point(948, 325);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(106, 42);
            this.button6.TabIndex = 8;
            this.button6.Text = "도서삭제";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Default;
            this.button5.Location = new System.Drawing.Point(836, 325);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(106, 42);
            this.button5.TabIndex = 8;
            this.button5.Text = "도서등록";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.Location = new System.Drawing.Point(838, 284);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(216, 25);
            this.textBox6.TabIndex = 8;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(838, 239);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(216, 25);
            this.textBox5.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(838, 194);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(216, 25);
            this.textBox4.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.Location = new System.Drawing.Point(838, 149);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(216, 25);
            this.textBox3.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.Location = new System.Drawing.Point(838, 104);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(216, 25);
            this.textBox2.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(763, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "ISBN : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(763, 242);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "출판사 : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(763, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "저자 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(763, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "발행일 :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(838, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(216, 25);
            this.textBox1.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(763, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "가격 : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(763, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "제목 : ";
            // 
            // BookRetunPan
            // 
            this.BookRetunPan.Controls.Add(this.button8);
            this.BookRetunPan.Controls.Add(this.button9);
            this.BookRetunPan.Controls.Add(this.button10);
            this.BookRetunPan.Controls.Add(this.textBox7);
            this.BookRetunPan.Controls.Add(this.textBox8);
            this.BookRetunPan.Controls.Add(this.textBox9);
            this.BookRetunPan.Controls.Add(this.label9);
            this.BookRetunPan.Controls.Add(this.label10);
            this.BookRetunPan.Controls.Add(this.label11);
            this.BookRetunPan.Controls.Add(this.textBox12);
            this.BookRetunPan.Controls.Add(this.label14);
            this.BookRetunPan.Controls.Add(this.bookReturnPan);
            this.BookRetunPan.Location = new System.Drawing.Point(10, 204);
            this.BookRetunPan.Name = "BookRetunPan";
            this.BookRetunPan.Size = new System.Drawing.Size(1145, 453);
            this.BookRetunPan.TabIndex = 9;
            this.BookRetunPan.Visible = false;
            // 
            // button8
            // 
            this.button8.Cursor = System.Windows.Forms.Cursors.Default;
            this.button8.Location = new System.Drawing.Point(964, 363);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(106, 42);
            this.button8.TabIndex = 8;
            this.button8.Text = "신청목록";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Cursor = System.Windows.Forms.Cursors.Default;
            this.button9.Location = new System.Drawing.Point(964, 315);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(106, 42);
            this.button9.TabIndex = 8;
            this.button9.Text = "도서삭제";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Cursor = System.Windows.Forms.Cursors.Default;
            this.button10.Location = new System.Drawing.Point(850, 315);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(106, 42);
            this.button10.TabIndex = 8;
            this.button10.Text = "도서등록";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox7.Location = new System.Drawing.Point(850, 234);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(216, 25);
            this.textBox7.TabIndex = 8;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox8.Location = new System.Drawing.Point(850, 175);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(216, 25);
            this.textBox8.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox9.Location = new System.Drawing.Point(850, 116);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(216, 25);
            this.textBox9.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(737, 236);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 16);
            this.label9.TabIndex = 7;
            this.label9.Text = "반납예정일 : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(737, 177);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 16);
            this.label10.TabIndex = 7;
            this.label10.Text = "출판사 : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(737, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 7;
            this.label11.Text = "저자 : ";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox12.Location = new System.Drawing.Point(850, 57);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(216, 25);
            this.textBox12.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(737, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "제목 : ";
            // 
            // bookReturnPan
            // 
            this.bookReturnPan.FormattingEnabled = true;
            this.bookReturnPan.HorizontalScrollbar = true;
            this.bookReturnPan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bookReturnPan.ItemHeight = 12;
            this.bookReturnPan.Items.AddRange(new object[] {
            "도서반납"});
            this.bookReturnPan.Location = new System.Drawing.Point(7, 51);
            this.bookReturnPan.MultiColumn = true;
            this.bookReturnPan.Name = "bookReturnPan";
            this.bookReturnPan.Size = new System.Drawing.Size(714, 364);
            this.bookReturnPan.TabIndex = 5;
            // 
            // BookSerchBtn
            // 
            this.BookSerchBtn.BackColor = System.Drawing.Color.Gray;
            this.BookSerchBtn.FlatAppearance.BorderSize = 0;
            this.BookSerchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookSerchBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BookSerchBtn.ForeColor = System.Drawing.Color.White;
            this.BookSerchBtn.Location = new System.Drawing.Point(24, 128);
            this.BookSerchBtn.Name = "BookSerchBtn";
            this.BookSerchBtn.Size = new System.Drawing.Size(93, 46);
            this.BookSerchBtn.TabIndex = 6;
            this.BookSerchBtn.Text = "도서검색";
            this.BookSerchBtn.UseVisualStyleBackColor = false;
            this.BookSerchBtn.Visible = false;
            this.BookSerchBtn.Click += new System.EventHandler(this.BookSerchBtn_Click);
            // 
            // BookRetunBtn
            // 
            this.BookRetunBtn.BackColor = System.Drawing.Color.Gray;
            this.BookRetunBtn.FlatAppearance.BorderSize = 0;
            this.BookRetunBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookRetunBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BookRetunBtn.ForeColor = System.Drawing.Color.White;
            this.BookRetunBtn.Location = new System.Drawing.Point(115, 128);
            this.BookRetunBtn.Name = "BookRetunBtn";
            this.BookRetunBtn.Size = new System.Drawing.Size(93, 46);
            this.BookRetunBtn.TabIndex = 6;
            this.BookRetunBtn.Text = "도서반납";
            this.BookRetunBtn.UseVisualStyleBackColor = false;
            this.BookRetunBtn.Visible = false;
            this.BookRetunBtn.Click += new System.EventHandler(this.BookRetunBtn_Click);
            // 
            // BookManagBtn
            // 
            this.BookManagBtn.BackColor = System.Drawing.Color.Gray;
            this.BookManagBtn.FlatAppearance.BorderSize = 0;
            this.BookManagBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookManagBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BookManagBtn.ForeColor = System.Drawing.Color.White;
            this.BookManagBtn.Location = new System.Drawing.Point(206, 128);
            this.BookManagBtn.Name = "BookManagBtn";
            this.BookManagBtn.Size = new System.Drawing.Size(93, 46);
            this.BookManagBtn.TabIndex = 6;
            this.BookManagBtn.Text = "도서관리";
            this.BookManagBtn.UseVisualStyleBackColor = false;
            this.BookManagBtn.Visible = false;
            this.BookManagBtn.Click += new System.EventHandler(this.BookManagBtn_Click);
            // 
            // BookSearchPan
            // 
            this.BookSearchPan.Controls.Add(this.button11);
            this.BookSearchPan.Controls.Add(this.button12);
            this.BookSearchPan.Controls.Add(this.textBox10);
            this.BookSearchPan.Controls.Add(this.textBox11);
            this.BookSearchPan.Controls.Add(this.textBox17);
            this.BookSearchPan.Controls.Add(this.textBox15);
            this.BookSearchPan.Controls.Add(this.label12);
            this.BookSearchPan.Controls.Add(this.label13);
            this.BookSearchPan.Controls.Add(this.textBox16);
            this.BookSearchPan.Controls.Add(this.label19);
            this.BookSearchPan.Controls.Add(this.label17);
            this.BookSearchPan.Controls.Add(this.label18);
            this.BookSearchPan.Controls.Add(this.listBox2);
            this.BookSearchPan.Location = new System.Drawing.Point(24, 181);
            this.BookSearchPan.Name = "BookSearchPan";
            this.BookSearchPan.Size = new System.Drawing.Size(1145, 453);
            this.BookSearchPan.TabIndex = 7;
            this.BookSearchPan.Visible = false;
            // 
            // button11
            // 
            this.button11.Cursor = System.Windows.Forms.Cursors.Default;
            this.button11.Location = new System.Drawing.Point(1060, 76);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(56, 25);
            this.button11.TabIndex = 8;
            this.button11.Text = "검색";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Cursor = System.Windows.Forms.Cursors.Default;
            this.button12.Location = new System.Drawing.Point(948, 254);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(106, 42);
            this.button12.TabIndex = 8;
            this.button12.Text = "도서검색";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox10.Location = new System.Drawing.Point(838, 213);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(216, 25);
            this.textBox10.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox11.Location = new System.Drawing.Point(838, 168);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(216, 25);
            this.textBox11.TabIndex = 8;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox17.Location = new System.Drawing.Point(962, 121);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(92, 25);
            this.textBox17.TabIndex = 8;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox15.Location = new System.Drawing.Point(838, 121);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(92, 25);
            this.textBox15.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(763, 216);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "ISBN : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(763, 171);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 16);
            this.label13.TabIndex = 7;
            this.label13.Text = "출판사 : ";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox16.Location = new System.Drawing.Point(838, 76);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(216, 25);
            this.textBox16.TabIndex = 8;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(936, 125);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(21, 16);
            this.label19.TabIndex = 7;
            this.label19.Text = "~";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(763, 124);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 16);
            this.label17.TabIndex = 7;
            this.label17.Text = "가격 : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(763, 79);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 16);
            this.label18.TabIndex = 7;
            this.label18.Text = "제목 : ";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.HorizontalScrollbar = true;
            this.listBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Items.AddRange(new object[] {
            "도서검색"});
            this.listBox2.Location = new System.Drawing.Point(7, 51);
            this.listBox2.MultiColumn = true;
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(714, 364);
            this.listBox2.TabIndex = 5;
            // 
            // ManagementBtn
            // 
            this.ManagementBtn.BackColor = System.Drawing.Color.Silver;
            this.ManagementBtn.FlatAppearance.BorderSize = 0;
            this.ManagementBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManagementBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ManagementBtn.ForeColor = System.Drawing.Color.White;
            this.ManagementBtn.Location = new System.Drawing.Point(206, 128);
            this.ManagementBtn.Name = "ManagementBtn";
            this.ManagementBtn.Size = new System.Drawing.Size(93, 46);
            this.ManagementBtn.TabIndex = 6;
            this.ManagementBtn.Text = "관리";
            this.ManagementBtn.UseVisualStyleBackColor = false;
            this.ManagementBtn.Visible = false;
            this.ManagementBtn.Click += new System.EventHandler(this.ManagementBtn_Click);
            // 
            // MemberBtn
            // 
            this.MemberBtn.BackColor = System.Drawing.Color.Silver;
            this.MemberBtn.FlatAppearance.BorderSize = 0;
            this.MemberBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MemberBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MemberBtn.ForeColor = System.Drawing.Color.White;
            this.MemberBtn.Location = new System.Drawing.Point(24, 128);
            this.MemberBtn.Name = "MemberBtn";
            this.MemberBtn.Size = new System.Drawing.Size(93, 46);
            this.MemberBtn.TabIndex = 6;
            this.MemberBtn.Text = "회원정보";
            this.MemberBtn.UseVisualStyleBackColor = false;
            this.MemberBtn.Visible = false;
            this.MemberBtn.Click += new System.EventHandler(this.MemberBtn_Click);
            // 
            // BookRequestBtn
            // 
            this.BookRequestBtn.BackColor = System.Drawing.Color.Silver;
            this.BookRequestBtn.FlatAppearance.BorderSize = 0;
            this.BookRequestBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookRequestBtn.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BookRequestBtn.ForeColor = System.Drawing.Color.White;
            this.BookRequestBtn.Location = new System.Drawing.Point(115, 128);
            this.BookRequestBtn.Name = "BookRequestBtn";
            this.BookRequestBtn.Size = new System.Drawing.Size(93, 46);
            this.BookRequestBtn.TabIndex = 6;
            this.BookRequestBtn.Text = "도서신청";
            this.BookRequestBtn.UseVisualStyleBackColor = false;
            this.BookRequestBtn.Visible = false;
            this.BookRequestBtn.Click += new System.EventHandler(this.BookRequestBtn_Click);
            // 
            // BookRequestPan
            // 
            this.BookRequestPan.Controls.Add(this.label24);
            this.BookRequestPan.Controls.Add(this.label23);
            this.BookRequestPan.Controls.Add(this.button2);
            this.BookRequestPan.Controls.Add(this.textBox13);
            this.BookRequestPan.Controls.Add(this.textBox14);
            this.BookRequestPan.Controls.Add(this.textBox18);
            this.BookRequestPan.Controls.Add(this.textBox19);
            this.BookRequestPan.Controls.Add(this.label15);
            this.BookRequestPan.Controls.Add(this.label16);
            this.BookRequestPan.Controls.Add(this.textBox20);
            this.BookRequestPan.Controls.Add(this.label20);
            this.BookRequestPan.Controls.Add(this.label21);
            this.BookRequestPan.Controls.Add(this.label22);
            this.BookRequestPan.Location = new System.Drawing.Point(24, 112);
            this.BookRequestPan.Name = "BookRequestPan";
            this.BookRequestPan.Size = new System.Drawing.Size(1145, 503);
            this.BookRequestPan.TabIndex = 7;
            this.BookRequestPan.Visible = false;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.label24.Location = new System.Drawing.Point(457, 92);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(250, 48);
            this.label24.TabIndex = 0;
            this.label24.Text = "Google 도서";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(497, 11);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(178, 48);
            this.label23.TabIndex = 0;
            this.label23.Text = "도서신청";
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Default;
            this.button2.Location = new System.Drawing.Point(529, 338);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 42);
            this.button2.TabIndex = 8;
            this.button2.Text = "신청하기";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox13.Location = new System.Drawing.Point(470, 296);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(216, 25);
            this.textBox13.TabIndex = 8;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox14.Location = new System.Drawing.Point(470, 251);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(216, 25);
            this.textBox14.TabIndex = 8;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox18.Location = new System.Drawing.Point(594, 204);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(92, 25);
            this.textBox18.TabIndex = 8;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox19.Location = new System.Drawing.Point(470, 204);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(92, 25);
            this.textBox19.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(395, 299);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 16);
            this.label15.TabIndex = 7;
            this.label15.Text = "발행일 : ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(395, 254);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 16);
            this.label16.TabIndex = 7;
            this.label16.Text = "출판사 : ";
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox20.Location = new System.Drawing.Point(470, 159);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(216, 25);
            this.textBox20.TabIndex = 8;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(568, 208);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 16);
            this.label20.TabIndex = 7;
            this.label20.Text = "~";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(395, 207);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 16);
            this.label21.TabIndex = 7;
            this.label21.Text = "저자 : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(395, 162);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 16);
            this.label22.TabIndex = 7;
            this.label22.Text = "제목 : ";
            // 
            // MemberPan
            // 
            this.MemberPan.Controls.Add(this.label26);
            this.MemberPan.Controls.Add(this.button1);
            this.MemberPan.Controls.Add(this.textBox21);
            this.MemberPan.Controls.Add(this.label27);
            this.MemberPan.Location = new System.Drawing.Point(24, 114);
            this.MemberPan.Name = "MemberPan";
            this.MemberPan.Size = new System.Drawing.Size(1145, 503);
            this.MemberPan.TabIndex = 7;
            this.MemberPan.Visible = false;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.Location = new System.Drawing.Point(443, 11);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(270, 48);
            this.label26.TabIndex = 0;
            this.label26.Text = "비밀번호 확인";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.Location = new System.Drawing.Point(500, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 42);
            this.button1.TabIndex = 8;
            this.button1.Text = ">";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox21.Location = new System.Drawing.Point(449, 131);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(216, 35);
            this.textBox21.TabIndex = 8;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.Location = new System.Drawing.Point(289, 135);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(154, 27);
            this.label27.TabIndex = 7;
            this.label27.Text = "비밀번호 : ";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1184, 718);
            this.Controls.Add(this.adminBtn);
            this.Controls.Add(this.BookBtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Join);
            this.Controls.Add(this.IDfind);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.RogeBtn);
            this.Controls.Add(this.BookSearchPan);
            this.Controls.Add(this.BookManagPan);
            this.Controls.Add(this.BookRequestBtn);
            this.Controls.Add(this.BookRetunBtn);
            this.Controls.Add(this.MemberBtn);
            this.Controls.Add(this.BookSerchBtn);
            this.Controls.Add(this.ManagementBtn);
            this.Controls.Add(this.BookManagBtn);
            this.Controls.Add(this.BookRetunPan);
            this.Controls.Add(this.BookRequestPan);
            this.Controls.Add(this.MemberPan);
            this.Name = "MainForm";
            this.Text = "도서관리 프로그램";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.BookManagPan.ResumeLayout(false);
            this.BookManagPan.PerformLayout();
            this.BookRetunPan.ResumeLayout(false);
            this.BookRetunPan.PerformLayout();
            this.BookSearchPan.ResumeLayout(false);
            this.BookSearchPan.PerformLayout();
            this.BookRequestPan.ResumeLayout(false);
            this.BookRequestPan.PerformLayout();
            this.MemberPan.ResumeLayout(false);
            this.MemberPan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RogeBtn;
        private System.Windows.Forms.TextBox ID;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Label IDfind;
        private System.Windows.Forms.Label Join;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BookBtn;
        private System.Windows.Forms.Button adminBtn;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel BookManagPan;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel BookRetunPan;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox bookReturnPan;
        private System.Windows.Forms.Button BookSerchBtn;
        private System.Windows.Forms.Button BookRetunBtn;
        private System.Windows.Forms.Button BookManagBtn;
        private System.Windows.Forms.Panel BookSearchPan;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button ManagementBtn;
        private System.Windows.Forms.Button MemberBtn;
        private System.Windows.Forms.Button BookRequestBtn;
        private System.Windows.Forms.Panel BookRequestPan;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel MemberPan;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label27;
    }
}

